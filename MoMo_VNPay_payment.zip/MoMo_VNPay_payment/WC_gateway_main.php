<?php
/*
Plugin Name: Cổng thanh toán VNPay & MoMo
Description: Tích hợp VNPay và MoMo vào WooCommerce.
Version: 1.0
Author: Ban IT
*/

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', 'init_custom_payment_gateways');

function init_custom_payment_gateways() {
    if (!class_exists('WC_Payment_Gateway')) return;

    // Load từng gateway riêng
    require_once plugin_dir_path(__FILE__) . 'includes/MOMO_payment.php';
    require_once plugin_dir_path(__FILE__) . 'includes/VNPAY_payment.php';

    add_filter('woocommerce_payment_gateways', 'add_custom_gateways');

    function add_custom_gateways($methods) {
        $methods[] = 'WC_Gateway_VNPAY';
        $methods[] = 'WC_Gateway_MOMO';
        return $methods;
    }
}
