<?php
if (!defined('ABSPATH')) exit;

class WC_Gateway_VNPAY extends WC_Payment_Gateway {
    public function __construct() {
        $this->id = 'vnpay';
        $this->method_title = __('VNPay Payment Gateway', 'woocommerce');
        $this->method_description = 'Thanh toán qua VNPay';
        $this->has_fields = false;

        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->vnpay_tmn_code = $this->get_option('tmncode');
        $this->vnpay_hash_secret = $this->get_option('hash_secret');
        $this->return_url = $this->get_option('return_url');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Bật/Tắt',
                'type' => 'checkbox',
                'label' => 'Bật VNPay Gateway',
                'default' => 'yes'
            ),
            'title' => array(
                'title' => 'Tiêu đề hiển thị',
                'type' => 'text',
                'default' => 'Thanh toán qua VNPay'
            ),
            'tmncode' => array(
                'title' => 'TmnCode (Mã Website)',
                'type' => 'text'
            ),
            'hash_secret' => array(
                'title' => 'Hash Secret',
                'type' => 'text'
            ),
            'return_url' => array(
                'title' => 'URL trả về sau khi thanh toán',
                'type' => 'text',
                'default' => home_url('/vnpay-return')
            )
        );
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        $vnp_TxnRef = $order_id;
        $vnp_Amount = $order->get_total() * 100;
        $vnp_Returnurl = $this->return_url;

        $inputData = array(
            "vnp_Version" => "2.1.0",
            "vnp_TmnCode" => $this->vnpay_tmn_code,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode" => "VND",
            "vnp_IpAddr" => $_SERVER['REMOTE_ADDR'],
            "vnp_Locale" => "vn",
            "vnp_OrderInfo" => 'Thanh toan don hang #' . $order_id,
            "vnp_OrderType" => "other",
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $vnp_TxnRef
        );

        ksort($inputData);
        $hashdata = urldecode(http_build_query($inputData));
        $secureHash = hash_hmac('sha512', $hashdata, $this->vnpay_hash_secret);

        $vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html?" . http_build_query($inputData) . '&vnp_SecureHash=' . $secureHash;

        return array(
            'result' => 'success',
            'redirect' => $vnp_Url
        );
    }
}